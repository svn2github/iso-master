#ifndef bkAdd_h
#define bkAdd_h

int addDir(Dir* tree, char* srcPath, Path* destDir);
int addFile(Dir* tree, char* srcPathAndName, Path* destDir);

#endif
