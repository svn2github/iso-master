#ifndef bkExtract_h
#define bkExtract_h

class GBLposixDefaults
{
    public:
    static const unsigned file = 33188; /* octal 100644 */
    static const unsigned dir = 16877; /* octal 40711 */
};

int extractDir(int image, Dir* tree, Path* srcDir, char* destDir,
                                                        bool keepPermissions);
int extractFile(int image, Dir* tree, FilePath* pathAndName, char* destDir,
                                                        bool keepPermissions);

#endif
