#ifndef bkDelete_h
#define bkDelete_h

int deleteDir(Dir* tree, Path* srcDir);
int deleteFile(Dir* tree, FilePath* pathAndName);

#endif
